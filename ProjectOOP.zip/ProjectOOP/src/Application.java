import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Application extends JFrame{
    private JTextField passwordTF;
    private JTextField usernameTF;
    private JButton loginButton;
    private JLabel LoginLabel;
    private JLabel UsernameLabel;
    private JLabel PasswordLabel;
    private JPanel rootPanel;
    private JLabel AppTitleLabel;
    private JButton SignUpButton;
    private String username;
    private String password;



    public Application()
    {

        usernameTF.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                    username = usernameTF.getText();

            }
        });


        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Staff staff = new Staff();
                staff.setContentPane(new Staff().staffPanel);
                staff.pack();
                staff.setVisible(true);
                dispose();
            }
        });


        SignUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Staff staff = new Staff();
                staff.setContentPane(new Staff().staffPanel);
                staff.pack();
                staff.setVisible(true);
                dispose();
            }
        });
        passwordTF.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                password = passwordTF.getText();
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("BarberShop Name");
        frame.setContentPane(new Application().rootPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public static class Staff extends Application{
        protected String username = "staff";
        protected String password = "staff";
        private JButton newReservationButton;
        private JButton payNowButton;
        private JButton viewScheduleButton;
        private JLabel loginInformationLabel;
        private JLabel dateInformationLabel;
        private JLabel todaysreservationsLabel;
        private JLabel newReservationInformationLabel;
        private JLabel servicesInformationLabel;
        private JLabel availableReservationSlotLabel;
        private JLabel LoginUserInfoLabel;
        private JLabel DateLabel;
        protected JPanel staffPanel;
        private JLabel clientInfo;
        private JLabel bookingInfo;
        private JLabel serviceInfo;
        private JLabel availInfo;

    }

    public static class Manager extends Staff {
        protected String ManagerUserName = "manager";
        protected String ManagerPassword = "manager";


        protected JPanel managerPanel;
        private JButton button1;
        private JButton button2;
        private JButton button3;
        private JButton button4;
        private JButton button5;

    }
}
